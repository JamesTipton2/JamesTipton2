﻿using System;
using System.Collections.Generic;
using System.Threading;

//Written By James Tipton, Credit to David Poole for assistance on method configuration.
//Code soure obtained from comments on Stack Overflow https://stackoverflow.com/questions/273313/randomize-a-listt/1262619#1262619
//Line 55- 60 are commented out, they will display the values of the list count and length as described in the comments above them.
namespace NameSelectorRandomCharacters
{
    class Program
    {
        public static void Main(string[] args)
        {
            List<object> CharacterList = new List<object>();
            string[] charactersArray = new string[] {
                "Bob Belcher", "Tina Belcher", "Linda Belcher", "Louise Belcher", "Gene Belcher", "Teddy", "Jimmy Jr.",//Bob's Burgers
                "Peter Griffin", "Lois Griffin", "Stewie Griffin", "Meg Griffin", "Glenn Quagmire", "Chris Griffin", "Joe Swanson", "Brian Griffin",//Family Guy
                "Hank Hill", "Dale Dribble", "Peggy Hill", "Luanne Platter", "Bill Dauterive", "Boomhauer", "John Redcorn",//King of the Hill
                "Philip J. Fry", "Turanga Leela", "Bender Bending Rodriguez", "Amy Wong", "Hermes Conrad", "Prof. Hubert J. Farsworth", "Doctor John Zoidberg", "Zapp Brannigan",//Futurama
                "Stan Smith", "Hayley Smith", "Steve Smith", "Roger Smith", "Klaus Heissler", "Francine Smith", "Avery Bullock", "Snot Lonstein"//American Dad
            };
            foreach (string name in charactersArray)
            {
                CharacterList.Add(name);
            }
            CharacterList.Shuffle();
        }
    }
    public static class ThreadSafeRandom
    {
        [ThreadStatic] private static Random Local;
        public static Random ThisThreadsRandom
        {
            get { return Local ?? (Local = new Random(unchecked(Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId))); }
        }
    }
    static class MyExtensions
    {
        public static void Shuffle<T>(this IList<T> list)
        {
            double counterList = 0;
            double characterList = 0;
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = ThreadSafeRandom.ThisThreadsRandom.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(value);
                //counterList += 1;
                //characterList = (list.Count - counterList);
                ////Counts the number of characters that have been diplayed 
                //Console.WriteLine(counterList);
                ////Counts the number of characters left in the list
                //Console.WriteLine(characterList);
                Console.WriteLine("Press the [Enter] key to draw the next Character");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}